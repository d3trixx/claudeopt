package com.claudeopt.mod.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Хранит собственные (не ванильные) переключатели ClaudeOpt
 * и сохраняет их в config/claudeoptmod.json.
 */
public class ClaudeOptConfig {

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("claudeoptmod.json");

    public static ClaudeOptConfig INSTANCE = load();

    // --- Пользовательские (кастомные) функции оптимизации ---
    // Это НЕ дублирует Sodium/ваниль: там нет автодальности по FPS,
    // лимитера частиц в тик и доп. отсечения сущностей поверх обычного.

    /** Доп. отсечение сущностей за радиусом сверх обычного (vanilla/Sodium этого не делают). */
    public boolean extraEntityCulling = false;
    public int extraCullDistance = 48; // блоков

    /** Урезает частицы дождя/снега. */
    public boolean weatherParticleLimiter = false;

    /** Урезает декоративные частицы взрывов (дым/обломки), не трогая саму вспышку. */
    public boolean explosionParticleLimiter = false;

    /** Жёсткий лимит декоративных частиц, спавнящихся за один тик (анти-лаг при фермах/PvP). */
    public boolean particleTickLimiterEnabled = false;
    public int particleTickCap = 40;

    /** Автоматически снижает/повышает дальность прорисовки по текущему FPS. */
    public boolean dynamicViewDistanceEnabled = false;
    public int dynamicViewDistanceTargetFps = 45;
    public int dynamicViewDistanceMin = 4;
    public int dynamicViewDistanceMax = 16;

    /** Небольшой оверлей FPS/чанков в углу экрана. */
    public boolean performanceHudEnabled = false;

    public static ClaudeOptConfig load() {
        if (Files.exists(PATH)) {
            try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
                ClaudeOptConfig cfg = GSON.fromJson(reader, ClaudeOptConfig.class);
                if (cfg != null) {
                    return cfg;
                }
            } catch (IOException | RuntimeException e) {
                com.claudeopt.mod.ClaudeOptMod.LOGGER.warn("[ClaudeOpt] Не удалось загрузить конфиг, использую значения по умолчанию.", e);
            }
        }
        return new ClaudeOptConfig();
    }

    public void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(this, writer);
            }
        } catch (IOException e) {
            com.claudeopt.mod.ClaudeOptMod.LOGGER.warn("[ClaudeOpt] Не удалось сохранить конфиг.", e);
        }
    }
}

package com.claudeopt.mod.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.GameOptions;

/**
 * Автоматически подстраивает дальность прорисовки под текущий FPS.
 * В отличие от ручного слайдера дальности (который уже есть и в ванили, и в Sodium),
 * это активная система: сама снижает дальность при просадках и поднимает обратно,
 * когда производительность позволяет — полезно на планшетах с нестабильным FPS.
 */
public final class DynamicViewDistanceManager {

    private static int cooldownTicks = 0;
    private static final int CHECK_INTERVAL_TICKS = 60; // примерно раз в 3 секунды

    private DynamicViewDistanceManager() {}

    public static void onClientTick(MinecraftClient client) {
        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        if (!cfg.dynamicViewDistanceEnabled || client.world == null) {
            cooldownTicks = 0;
            return;
        }

        if (cooldownTicks > 0) {
            cooldownTicks--;
            return;
        }

        GameOptions options = client.options;
        int currentDistance = options.getViewDistance().getValue();
        int fps = PerformanceMonitor.getLastFps();
        int target = cfg.dynamicViewDistanceTargetFps;

        if (fps < target - 5 && currentDistance > cfg.dynamicViewDistanceMin) {
            options.getViewDistance().setValue(currentDistance - 1);
            options.write();
            cooldownTicks = CHECK_INTERVAL_TICKS;
        } else if (fps > target + 15 && currentDistance < cfg.dynamicViewDistanceMax) {
            options.getViewDistance().setValue(currentDistance + 1);
            options.write();
            cooldownTicks = CHECK_INTERVAL_TICKS;
        }
    }
}

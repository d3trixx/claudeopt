package com.claudeopt.mod.client;

/**
 * Собственный лёгкий счётчик FPS (не зависит от внутренних полей MinecraftClient,
 * которые могут менять имя между версиями). Обновляется из WorldRenderEvents.END
 * в ClaudeOptModClient.
 */
public final class PerformanceMonitor {

    private static int frameCounter = 0;
    private static long windowStartMs = System.currentTimeMillis();
    private static volatile int lastFps = 60;

    private PerformanceMonitor() {}

    /** Вызывается один раз за отрисованный кадр. */
    public static void onFrameRendered() {
        frameCounter++;
        long now = System.currentTimeMillis();
        long elapsed = now - windowStartMs;
        if (elapsed >= 1000) {
            lastFps = (int) Math.round(frameCounter * 1000.0 / elapsed);
            frameCounter = 0;
            windowStartMs = now;
        }
    }

    public static int getLastFps() {
        return lastFps;
    }
}

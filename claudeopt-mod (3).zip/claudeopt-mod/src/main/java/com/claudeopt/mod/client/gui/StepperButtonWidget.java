package com.claudeopt.mod.client.gui;

import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.text.Text;

import java.util.function.Function;
import java.util.function.IntSupplier;
import java.util.function.IntUnaryOperator;

/**
 * Кнопка-"степпер" для числовых настроек.
 * ЛКМ (левый клик) — увеличить значение.
 * ПКМ (правый клик) — уменьшить значение.
 */
public class StepperButtonWidget extends ButtonWidget {

    private final int min;
    private final int max;
    private final int step;
    private final IntSupplier getter;
    private final IntUnaryOperator setter; // принимает желаемое значение, возвращает фактически применённое
    private final Function<Integer, String> formatter;

    public StepperButtonWidget(int x, int y, int width, int height,
                                int min, int max, int step,
                                IntSupplier getter, IntUnaryOperator setter,
                                Function<Integer, String> formatter) {
        super(x, y, width, height, Text.literal(""), b -> {}, DEFAULT_NARRATION_SUPPLIER);
        this.min = min;
        this.max = max;
        this.step = step;
        this.getter = getter;
        this.setter = setter;
        this.formatter = formatter;
        refreshLabel();
    }

    private void refreshLabel() {
        this.setMessage(Text.literal(formatter.apply(getter.getAsInt())));
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        if (!this.isMouseOver(mouseX, mouseY) || !this.active || !this.visible) {
            return false;
        }
        int current = getter.getAsInt();
        int delta = (button == 1) ? -step : step; // ПКМ = минус, иначе плюс
        int next = Math.max(min, Math.min(max, current + delta));
        if (next != current) {
            setter.applyAsInt(next);
        }
        refreshLabel();
        return true;
    }
}

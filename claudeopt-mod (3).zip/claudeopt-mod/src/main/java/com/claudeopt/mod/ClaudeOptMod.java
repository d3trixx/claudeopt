package com.claudeopt.mod;

import net.fabricmc.api.ModInitializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * ClaudeOpt — клиентский мод-оптимизатор.
 * Вся логика находится на клиенте (см. ClaudeOptModClient),
 * этот класс нужен только как общая точка входа, требуемая Fabric Loader.
 */
public class ClaudeOptMod implements ModInitializer {

    public static final String MOD_ID = "claudeoptmod";
    public static final Logger LOGGER = LoggerFactory.getLogger("ClaudeOpt");

    @Override
    public void onInitialize() {
        LOGGER.info("[ClaudeOpt] Мод загружен. Нажмите 'O' в игре или введите /claudeopt, чтобы открыть меню оптимизации.");
    }
}

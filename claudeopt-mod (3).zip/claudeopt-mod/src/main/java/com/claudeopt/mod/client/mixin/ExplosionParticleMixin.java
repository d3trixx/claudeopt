package com.claudeopt.mod.client.mixin;

import com.claudeopt.mod.client.ClaudeOptConfig;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Урезает часть декоративных частиц взрыва (клубы дыма/обломки), чтобы
 * серии взрывов (TNT-пушки, крипперы толпой) меньше просаживали FPS.
 * Основная частица взрыва (вспышка) никогда не трогается.
 */
@Mixin(ClientWorld.class)
public abstract class ExplosionParticleMixin {

    @Inject(method = "addParticleClient", at = @At("HEAD"), cancellable = true)
    private void claudeopt$limitExplosionParticles(ParticleEffect parameters, boolean force, boolean canSpawnOnMinimal,
                                                    double x, double y, double z,
                                                    double velocityX, double velocityY, double velocityZ,
                                                    CallbackInfo ci) {
        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        if (!cfg.explosionParticleLimiter) {
            return;
        }
        if (parameters == ParticleTypes.EXPLOSION_EMITTER
                || parameters == ParticleTypes.POOF
                || parameters == ParticleTypes.LARGE_SMOKE) {
            if (ThreadLocalRandom.current().nextFloat() < 0.6F) {
                ci.cancel();
            }
        }
    }
}

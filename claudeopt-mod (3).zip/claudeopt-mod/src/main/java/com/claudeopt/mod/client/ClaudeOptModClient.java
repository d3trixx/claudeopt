package com.claudeopt.mod.client;

import com.claudeopt.mod.client.gui.ClaudeOptScreen;
import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;

public class ClaudeOptModClient implements ClientModInitializer {

    private static KeyBinding openMenuKey;

    @Override
    public void onInitializeClient() {

        // --- Клавиша "O" для открытия меню ---
        openMenuKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.claudeoptmod.open_menu",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_O,
                "key.category.claudeoptmod"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openMenuKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new ClaudeOptScreen(null));
                }
            }
        });

        // --- Команда /claudeopt в чате ---
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) -> {
            dispatcher.register(ClientCommandManager.literal("claudeopt")
                    .executes(context -> {
                        MinecraftClient client = MinecraftClient.getInstance();
                        client.send(() -> client.setScreen(new ClaudeOptScreen(null)));
                        return Command.SINGLE_SUCCESS;
                    }));
        });

        // --- Счётчик FPS (для автодальности и оверлея) ---
        WorldRenderEvents.END.register(context -> PerformanceMonitor.onFrameRendered());

        // --- Автоматическая дальность прорисовки по FPS ---
        ClientTickEvents.END_CLIENT_TICK.register(DynamicViewDistanceManager::onClientTick);

        // --- Оверлей производительности ---
        HudRenderCallback.EVENT.register((drawContext, tickCounter) -> PerformanceHud.render(drawContext));

        com.claudeopt.mod.ClaudeOptMod.LOGGER.info("[ClaudeOpt] Клиентская часть инициализирована.");
    }
}

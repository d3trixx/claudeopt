package com.claudeopt.mod.client.mixin;

import com.claudeopt.mod.client.ClaudeOptConfig;
import net.minecraft.client.world.ClientWorld;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import java.util.concurrent.ThreadLocalRandom;

/**
 * Урезает количество частиц дождя/снега (брызги и капли) для экономии FPS
 * во время грозы/снегопада, когда в меню включена опция "Лимит частиц погоды".
 */
@Mixin(ClientWorld.class)
public abstract class WeatherParticleMixin {

    @Inject(method = "addParticleClient", at = @At("HEAD"), cancellable = true)
    private void claudeopt$limitWeatherParticles(ParticleEffect parameters, boolean force, boolean canSpawnOnMinimal,
                                                  double x, double y, double z,
                                                  double velocityX, double velocityY, double velocityZ,
                                                  CallbackInfo ci) {
        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        if (!cfg.weatherParticleLimiter) {
            return;
        }
        if (parameters == ParticleTypes.RAIN || parameters == ParticleTypes.SPLASH) {
            // Пропускаем примерно 70% частиц погоды
            if (ThreadLocalRandom.current().nextFloat() < 0.7F) {
                ci.cancel();
            }
        }
    }
}

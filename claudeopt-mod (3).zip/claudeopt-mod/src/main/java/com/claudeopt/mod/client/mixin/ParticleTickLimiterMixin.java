package com.claudeopt.mod.client.mixin;

import com.claudeopt.mod.client.ClaudeOptConfig;
import net.minecraft.client.particle.Particle;
import net.minecraft.client.particle.ParticleManager;
import net.minecraft.particle.ParticleEffect;
import net.minecraft.particle.ParticleTypes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.Set;

/**
 * В ВАНИЛИ и Sodium настройка "Частицы" (Все/Меньше/Минимум) — это общий
 * множитель для ВСЕХ частиц сразу и выбирается один раз в настройках.
 * Эта функция — другое: это ЖЁСТКИЙ лимит декоративных частиц, которые могут
 * заспавниться за один конкретный тик (например, при взрыве фермы крипперов
 * или стрельбе TNT-пушки), при этом остальное время частицы работают как обычно.
 * Игровые/важные эффекты (критический удар, зачарование, зелья) не трогаются.
 */
@Mixin(ParticleManager.class)
public abstract class ParticleTickLimiterMixin {

    private static int claudeopt$spawnedThisTick = 0;

    private static final Set<net.minecraft.particle.ParticleType<?>> DECORATIVE_TYPES = Set.of(
            ParticleTypes.SMOKE,
            ParticleTypes.LARGE_SMOKE,
            ParticleTypes.CLOUD,
            ParticleTypes.POOF,
            ParticleTypes.FLAME,
            ParticleTypes.CAMPFIRE_COSY_SMOKE,
            ParticleTypes.CAMPFIRE_SIGNAL_SMOKE,
            ParticleTypes.ASH,
            ParticleTypes.WHITE_ASH
    );

    @Inject(method = "tick", at = @At("HEAD"))
    private void claudeopt$resetCounter(CallbackInfo ci) {
        claudeopt$spawnedThisTick = 0;
    }

    @Inject(method = "addParticle(Lnet/minecraft/particle/ParticleEffect;DDDDDD)Lnet/minecraft/client/particle/Particle;",
            at = @At("HEAD"), cancellable = true)
    private void claudeopt$limitParticlesPerTick(ParticleEffect parameters, double x, double y, double z,
                                                  double velocityX, double velocityY, double velocityZ,
                                                  CallbackInfoReturnable<Particle> cir) {
        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        if (!cfg.particleTickLimiterEnabled) {
            return;
        }
        if (!DECORATIVE_TYPES.contains(parameters.getType())) {
            return;
        }
        if (claudeopt$spawnedThisTick >= cfg.particleTickCap) {
            cir.setReturnValue(null);
            return;
        }
        claudeopt$spawnedThisTick++;
    }
}

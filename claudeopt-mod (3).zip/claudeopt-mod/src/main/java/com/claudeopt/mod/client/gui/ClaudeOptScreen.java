package com.claudeopt.mod.client.gui;

import com.claudeopt.mod.client.ClaudeOptConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.GameOptions;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Меню ClaudeOpt — набор функций, которых нет ни в ванили, ни в Sodium:
 * доп. отсечение сущностей, лимит частиц погоды/взрывов/в тик,
 * автоматическая дальность прорисовки по FPS и оверлей производительности.
 * Открывается клавишей "O" или командой /claudeopt.
 */
public class ClaudeOptScreen extends Screen {

    private final Screen parent;
    private int panelX, panelY, panelWidth, panelHeight;

    public ClaudeOptScreen(Screen parent) {
        super(Text.literal("ClaudeOpt"));
        this.parent = parent;
    }

    @Override
    protected void init() {
        super.init();

        panelWidth = Math.min(380, this.width - 20);
        panelHeight = Math.min(300, this.height - 30);
        panelX = (this.width - panelWidth) / 2;
        panelY = (this.height - panelHeight) / 2;

        int rowWidth = panelWidth - 24;
        int x = panelX + 12;
        int y = panelY + 30;
        int rowHeight = 20;
        int gap = 4;

        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        GameOptions options = MinecraftClient.getInstance().options;

        // 1. Доп. отсечение сущностей
        addCycleButton(x, y, rowWidth,
                () -> "Доп. отсечение сущностей: " + onOff(cfg.extraEntityCulling),
                () -> { cfg.extraEntityCulling = !cfg.extraEntityCulling; cfg.save(); });
        y += rowHeight + gap;

        addStepper(x, y, rowWidth, 16, 128, 8,
                () -> cfg.extraCullDistance,
                v -> { cfg.extraCullDistance = v; cfg.save(); return v; },
                v -> "Радиус отсечения: " + v + " бл.");
        y += rowHeight + gap;

        // 2. Лимит частиц погоды
        addCycleButton(x, y, rowWidth,
                () -> "Лимит частиц погоды: " + onOff(cfg.weatherParticleLimiter),
                () -> { cfg.weatherParticleLimiter = !cfg.weatherParticleLimiter; cfg.save(); });
        y += rowHeight + gap;

        // 3. Лимит частиц взрывов
        addCycleButton(x, y, rowWidth,
                () -> "Лимит частиц взрывов: " + onOff(cfg.explosionParticleLimiter),
                () -> { cfg.explosionParticleLimiter = !cfg.explosionParticleLimiter; cfg.save(); });
        y += rowHeight + gap;

        // 4. Жёсткий лимит частиц в тик
        addCycleButton(x, y, rowWidth,
                () -> "Лимит частиц/тик: " + onOff(cfg.particleTickLimiterEnabled),
                () -> { cfg.particleTickLimiterEnabled = !cfg.particleTickLimiterEnabled; cfg.save(); });
        y += rowHeight + gap;

        addStepper(x, y, rowWidth, 5, 200, 5,
                () -> cfg.particleTickCap,
                v -> { cfg.particleTickCap = v; cfg.save(); return v; },
                v -> "Макс. частиц за тик: " + v);
        y += rowHeight + gap;

        // 5. Автодальность по FPS
        addCycleButton(x, y, rowWidth,
                () -> "Автодальность по FPS: " + onOff(cfg.dynamicViewDistanceEnabled),
                () -> { cfg.dynamicViewDistanceEnabled = !cfg.dynamicViewDistanceEnabled; cfg.save(); });
        y += rowHeight + gap;

        addStepper(x, y, rowWidth, 15, 120, 5,
                () -> cfg.dynamicViewDistanceTargetFps,
                v -> { cfg.dynamicViewDistanceTargetFps = v; cfg.save(); return v; },
                v -> "Целевой FPS: " + v);
        y += rowHeight + gap;

        // 6. Оверлей производительности
        addCycleButton(x, y, rowWidth,
                () -> "Оверлей FPS/чанков: " + onOff(cfg.performanceHudEnabled),
                () -> { cfg.performanceHudEnabled = !cfg.performanceHudEnabled; cfg.save(); });
        y += rowHeight + gap;

        // 7. Режим энергосбережения (планшет) — готовый пресет в один клик
        this.addDrawableChild(ButtonWidget.builder(
                        Text.literal("⚡ Режим энергосбережения (планшет)").formatted(Formatting.GOLD),
                        b -> applyLowPowerPreset(options, cfg))
                .dimensions(x, y, rowWidth, 20).build());
        y += rowHeight + gap + 4;

        // Нижние кнопки
        int halfWidth = (rowWidth - 6) / 2;
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Сбросить всё"), b -> resetAll(options, cfg))
                .dimensions(x, y, halfWidth, 20).build());
        this.addDrawableChild(ButtonWidget.builder(Text.literal("Закрыть"), b -> close())
                .dimensions(x + halfWidth + 6, y, halfWidth, 20).build());

        panelHeight = (y + 20 + 14) - panelY;
    }

    /**
     * Один клик — набор настроек под слабые/мобильные устройства (планшеты, PojavLauncher и т.п.):
     * включает все кастомные ограничители ClaudeOpt и мягко снижает лимит кадров для экономии батареи.
     */
    private void applyLowPowerPreset(GameOptions options, ClaudeOptConfig cfg) {
        cfg.extraEntityCulling = true;
        cfg.extraCullDistance = 32;
        cfg.weatherParticleLimiter = true;
        cfg.explosionParticleLimiter = true;
        cfg.particleTickLimiterEnabled = true;
        cfg.particleTickCap = 20;
        cfg.dynamicViewDistanceEnabled = true;
        cfg.dynamicViewDistanceTargetFps = 30;
        cfg.dynamicViewDistanceMin = 3;
        cfg.dynamicViewDistanceMax = 10;
        cfg.performanceHudEnabled = true;
        cfg.save();

        // Небольшое снижение лимита FPS экономит батарею на мобильных устройствах.
        options.getMaxFps().setValue(Math.min(options.getMaxFps().getValue(), 60));
        options.write();

        this.clearAndInit();
    }

    private void addStepper(int x, int y, int width, int min, int max, int step,
                             java.util.function.IntSupplier getter,
                             java.util.function.IntUnaryOperator setter,
                             java.util.function.IntFunction<String> labelFn) {
        this.addDrawableChild(new StepperButtonWidget(x, y, width, 20, min, max, step,
                getter, setter, labelFn::apply));
    }

    private void addCycleButton(int x, int y, int width,
                                 java.util.function.Supplier<String> labelFn,
                                 Runnable onClick) {
        this.addDrawableChild(ButtonWidget.builder(Text.literal(labelFn.get()), b -> {
            onClick.run();
            b.setMessage(Text.literal(labelFn.get()));
        }).dimensions(x, y, width, 20).build());
    }

    private void resetAll(GameOptions options, ClaudeOptConfig cfg) {
        cfg.extraEntityCulling = false;
        cfg.extraCullDistance = 48;
        cfg.weatherParticleLimiter = false;
        cfg.explosionParticleLimiter = false;
        cfg.particleTickLimiterEnabled = false;
        cfg.particleTickCap = 40;
        cfg.dynamicViewDistanceEnabled = false;
        cfg.dynamicViewDistanceTargetFps = 45;
        cfg.dynamicViewDistanceMin = 4;
        cfg.dynamicViewDistanceMax = 16;
        cfg.performanceHudEnabled = false;
        cfg.save();
        this.clearAndInit();
    }

    private static String onOff(boolean value) {
        return value ? "§aВКЛ" : "§cВЫКЛ";
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        this.renderBackground(context, mouseX, mouseY, delta);

        context.fill(panelX - 2, panelY - 2, panelX + panelWidth + 2, panelY + panelHeight + 2, 0x80000000);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + panelHeight, 0xE6101018);
        context.fill(panelX, panelY, panelX + panelWidth, panelY + 2, 0xFF55C2FF);
        context.fill(panelX, panelY + panelHeight - 2, panelX + panelWidth, panelY + panelHeight, 0xFF55C2FF);
        context.fill(panelX, panelY, panelX + 2, panelY + panelHeight, 0xFF55C2FF);
        context.fill(panelX + panelWidth - 2, panelY, panelX + panelWidth, panelY + panelHeight, 0xFF55C2FF);

        context.drawCenteredTextWithShadow(this.textRenderer,
                Text.literal("⚡ ClaudeOpt").formatted(Formatting.AQUA, Formatting.BOLD),
                panelX + panelWidth / 2, panelY + 10, 0xFFFFFF);

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }

    @Override
    public void close() {
        if (this.client != null) {
            this.client.setScreen(parent);
        }
    }
}

package com.claudeopt.mod.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;
import net.minecraft.util.Formatting;

/**
 * Маленький оверлей в углу экрана: FPS и число загруженных чанков.
 * Нужен, чтобы сразу видеть эффект от включённых функций ClaudeOpt —
 * ни ваниль, ни Sodium такого простого индикатора по умолчанию не показывают.
 */
public final class PerformanceHud {

    private PerformanceHud() {}

    public static void render(DrawContext context) {
        if (!ClaudeOptConfig.INSTANCE.performanceHudEnabled) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.options.hudHidden) {
            return;
        }

        int fps = PerformanceMonitor.getLastFps();
        int chunks = client.world != null ? client.world.getChunkManager().getLoadedChunkCount() : 0;

        Formatting fpsColor = fps >= 45 ? Formatting.GREEN : (fps >= 25 ? Formatting.YELLOW : Formatting.RED);

        Text line = Text.literal("ClaudeOpt  ")
                .formatted(Formatting.AQUA)
                .append(Text.literal("FPS: " + fps + "  ").formatted(fpsColor))
                .append(Text.literal("Чанков: " + chunks).formatted(Formatting.GRAY));

        context.drawTextWithShadow(client.textRenderer, line, 6, 6, 0xFFFFFF);
    }
}

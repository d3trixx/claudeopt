package com.claudeopt.mod.client.mixin;

import com.claudeopt.mod.client.ClaudeOptConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.Frustum;
import net.minecraft.client.render.entity.EntityRenderer;
import net.minecraft.client.render.entity.state.EntityRenderState;
import net.minecraft.entity.Entity;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

/**
 * Доп. отсечение (culling) сущностей за пределами настраиваемого радиуса.
 * Работает поверх стандартного vanilla-отсечения и позволяет дополнительно
 * сэкономить FPS на слабых ПК при включении "Доп. отсечение сущностей" в меню.
 */
@Mixin(EntityRenderer.class)
public abstract class EntityCullingMixin<T extends Entity, S extends EntityRenderState> {

    @Inject(method = "shouldRender", at = @At("HEAD"), cancellable = true)
    private void claudeopt$cullFarEntities(T entity, Frustum frustum, double x, double y, double z,
                                            CallbackInfoReturnable<Boolean> cir) {
        ClaudeOptConfig cfg = ClaudeOptConfig.INSTANCE;
        if (!cfg.extraEntityCulling) {
            return;
        }
        MinecraftClient client = MinecraftClient.getInstance();
        if (client.player != null && entity == client.player) {
            return; // никогда не скрываем самого игрока
        }
        double dx = entity.getX() - x;
        double dy = entity.getY() - y;
        double dz = entity.getZ() - z;
        double distSq = dx * dx + dy * dy + dz * dz;
        double max = cfg.extraCullDistance;
        if (distSq > max * max) {
            cir.setReturnValue(false);
        }
    }
}
